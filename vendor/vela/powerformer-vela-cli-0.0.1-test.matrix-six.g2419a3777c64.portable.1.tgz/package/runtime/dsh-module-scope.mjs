// DSH 0.1.2 walks package symlinks without canonicalizing each dependency's
// owner. In a pnpm workspace containing another DSH version, its loader can
// therefore select the other installation's hoisted plugins. Project only the
// fixed Vela installation's real plugin directories into this launch's private
// profile; never alter the consumer's node_modules or upstream package files.
import {
  lstatSync,
  mkdirSync,
  mkdtempSync,
  readFileSync,
  realpathSync,
  renameSync,
  rmSync,
  symlinkSync,
} from "node:fs";
import { createRequire } from "node:module";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const packageRoot = dirname(dirname(fileURLToPath(import.meta.url)));
const pluginName = /^@deepseek-ai\/[a-z0-9][a-z0-9-]*$/;

function packageAt(dir, name) {
  const canonical = realpathSync(dir);
  const manifest = JSON.parse(
    readFileSync(join(canonical, "package.json"), "utf8"),
  );
  if (manifest.name !== name)
    throw new Error(`DSH package identity mismatch: ${name}`);
  return { dir: canonical, manifest };
}

function resolvePackage(owner, name) {
  const require = createRequire(join(realpathSync(owner), "package.json"));
  for (const searchPath of require.resolve.paths(name) ?? []) {
    const candidate = join(searchPath, name);
    try {
      lstatSync(join(candidate, "package.json"));
    } catch (error) {
      if (error.code === "ENOENT") continue;
      throw error;
    }
    return packageAt(candidate, name);
  }
  throw new Error(`Missing installed DSH dependency: ${name}`);
}

export function collectDSHModules(entry, owner = packageRoot) {
  const meta = JSON.parse(readFileSync(join(owner, "package.json"), "utf8"));
  const modules = new Map();
  // The meta package declares the ABI and wire determinants explicitly.
  for (const [name, expected] of Object.entries(meta.dependencies ?? {})) {
    if (!pluginName.test(name)) continue;
    const pkg = resolvePackage(owner, name);
    if (pkg.manifest.version !== expected)
      throw new Error(
        `${name} version mismatch: require ${expected}, found ${pkg.manifest.version}`,
      );
    modules.set(name, pkg);
  }
  const dsh = modules.get("@deepseek-ai/dsh");
  if (!dsh || realpathSync(entry) !== realpathSync(join(dsh.dir, "lib/bin.js")))
    throw new Error(
      "DSH CLI and Vela profile must belong to the same installed package",
    );

  const queue = [...modules.values()];
  for (let index = 0; index < queue.length; index++) {
    const current = queue[index];
    const dependencies = {
      ...current.manifest.peerDependencies,
      ...current.manifest.dependencies,
    };
    for (const name of Object.keys(dependencies)) {
      if (!pluginName.test(name) || modules.has(name)) continue;
      let pkg;
      try {
        pkg = resolvePackage(current.dir, name);
      } catch (error) {
        if (
          !current.manifest.dependencies?.[name] &&
          current.manifest.peerDependenciesMeta?.[name]?.optional
        )
          continue;
        throw error;
      }
      if (
        name.startsWith("@deepseek-ai/dsh-") &&
        pkg.manifest.version !== dsh.manifest.version
      )
        throw new Error(
          `${name} version mismatch: require ${dsh.manifest.version}, found ${pkg.manifest.version}`,
        );
      modules.set(name, pkg);
      queue.push(pkg);
    }
  }
  return new Map([...modules].map(([name, pkg]) => [name, pkg.dir]));
}

export function prepareDSHModules(entry, profileDir, owner = packageRoot) {
  if (!lstatSync(profileDir).isDirectory())
    throw new Error("DSH profile must be a private directory");
  // Resolve and validate the whole graph before materializing any links.
  const modules = collectDSHModules(entry, owner);
  const profile = realpathSync(profileDir);
  const destination = join(profile, "node_modules");
  try {
    lstatSync(destination);
    throw new Error("DSH private module scope already exists");
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
  }
  const staging = mkdtempSync(join(profile, ".vela-modules-"));
  try {
    mkdirSync(join(staging, "@deepseek-ai"));
    for (const [name, dir] of modules)
      symlinkSync(
        dir,
        join(staging, name),
        process.platform === "win32" ? "junction" : "dir",
      );
    renameSync(staging, destination);
  } catch (error) {
    rmSync(staging, { recursive: true, force: true });
    throw error;
  }
  return modules.size;
}

if (
  process.argv[1] &&
  resolve(process.argv[1]) === fileURLToPath(import.meta.url)
) {
  if (process.argv.length !== 4)
    throw new Error(
      "Usage: dsh-module-scope.mjs <dsh-entry> <private-profile-dir>",
    );
  prepareDSHModules(process.argv[2], process.argv[3]);
}
