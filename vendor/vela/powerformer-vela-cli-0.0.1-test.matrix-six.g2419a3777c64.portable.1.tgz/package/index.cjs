"use strict";

const fs = require("node:fs");
const path = require("node:path");
const { createRequire } = require("node:module");

const platformPackages = {
  "darwin-arm64": "@powerformer/vela-cli-darwin-arm64",
  "darwin-x64": "@powerformer/vela-cli-darwin-x64",
  "linux-arm64": "@powerformer/vela-cli-linux-arm64",
  "linux-x64": "@powerformer/vela-cli-linux-x64",
  "win32-x64": "@powerformer/vela-cli-win32-x64",
};

function platformKey() {
  return `${process.platform}-${process.arch}`;
}

function unsupportedPlatformError() {
  return new Error(
    `Vela CLI is not packaged for ${process.platform}/${process.arch}`,
  );
}

function missingBinaryError(packageName, cause) {
  const details =
    cause instanceof Error && cause.message ? `: ${cause.message}` : "";
  return new Error(
    `Vela CLI binary package ${packageName} is not installed or is incomplete${details}`,
  );
}

function resolvePackageBinary(packageName) {
  const packageJSON = resolvePackageJSON(packageName);
  const binary = path.join(
    path.dirname(packageJSON),
    "bin",
    process.platform === "win32" ? "vela.exe" : "vela",
  );
  if (!fs.existsSync(binary)) {
    throw missingBinaryError(packageName);
  }
  return binary;
}

function resolvePackageJSON(packageName) {
  try {
    return require.resolve(`${packageName}/package.json`);
  } catch (error) {
    // Workspace/dev fallback: resolve the sibling platform package directory by
    // name when it is not yet linked into node_modules.
    const siblingDir = packageName.replace(/^@powerformer\//u, "");
    const sourcePackageJSON = path.resolve(
      __dirname,
      "..",
      siblingDir,
      "package.json",
    );
    if (
      Object.values(platformPackages).includes(packageName) &&
      fs.existsSync(sourcePackageJSON)
    ) {
      return sourcePackageJSON;
    }
    throw error;
  }
}

function resolveVelaCliBin(options = {}) {
  const strict = options.strict === true;
  const packageName = platformPackages[platformKey()];
  if (!packageName) {
    if (strict) {
      throw unsupportedPlatformError();
    }
    return null;
  }

  try {
    return resolvePackageBinary(packageName);
  } catch (error) {
    if (strict) {
      throw missingBinaryError(packageName, error);
    }
    return null;
  }
}

// Pi is an ESM-only package and deliberately does not export package.json.
// Follow this package's dependency search roots without importing its CLI.
function resolveVelaPiBin(options = {}) {
  const packageName = "@earendil-works/pi-coding-agent";
  try {
    for (const root of require.resolve.paths(packageName) ?? []) {
      if (path.basename(root) !== "node_modules") continue;
      const packageRoot = path.join(root, packageName);
      const manifestPath = path.join(packageRoot, "package.json");
      if (!fs.existsSync(manifestPath)) continue;
      const manifest = JSON.parse(fs.readFileSync(manifestPath, "utf8"));
      if (manifest.name !== packageName || manifest.version !== "0.85.1") {
        throw new Error(
          "Vela Pi requires @earendil-works/pi-coding-agent@0.85.1",
        );
      }
      const entry = path.join(packageRoot, "dist", "bundle", "cli.js");
      if (!fs.statSync(entry).isFile())
        throw new Error("Vela Pi CLI entry is missing");
      return fs.realpathSync(entry);
    }
    throw new Error("Vela Pi dependency is not installed");
  } catch (error) {
    if (options.strict === true) throw error;
    return null;
  }
}

// Resolve from this package's dependency tree, never a user's global CLI.
function resolvePinnedRuntime(
  packageName,
  version,
  relativeEntry,
  strict,
  owner = require,
) {
  try {
    for (const root of owner.resolve.paths(packageName) ?? []) {
      if (path.basename(root) !== "node_modules") continue;
      const packageRoot = path.join(root, packageName);
      const manifestPath = path.join(packageRoot, "package.json");
      if (!fs.existsSync(manifestPath)) continue;
      const manifest = JSON.parse(fs.readFileSync(manifestPath, "utf8"));
      if (manifest.name !== packageName || manifest.version !== version) {
        throw new Error(`Vela requires ${packageName}@${version}`);
      }
      const entry = path.join(packageRoot, relativeEntry);
      if (!fs.statSync(entry).isFile())
        throw new Error(`Missing ${packageName} CLI entry`);
      return fs.realpathSync(entry);
    }
    throw new Error(
      `Vela dependency ${packageName}@${version} is not installed`,
    );
  } catch (error) {
    if (strict) throw error;
    return null;
  }
}

function resolveVelaCodexBin(options = {}) {
  return resolvePinnedRuntime(
    "@openai/codex",
    "0.153.2",
    "bin/codex.js",
    options.strict === true,
  );
}
function resolveVelaClaudeBin(options = {}) {
  try {
    const wrapper = resolvePinnedRuntime(
      "@anthropic-ai/claude-code",
      "2.1.263",
      "cli-wrapper.cjs",
      true,
    );
    let cpu = process.arch;
    if (process.platform === "darwin" && cpu === "x64") {
      const translated = require("node:child_process").spawnSync(
        "sysctl",
        ["-n", "sysctl.proc_translated"],
        { encoding: "utf8", timeout: 2000 },
      );
      if (translated.stdout?.trim() === "1") cpu = "arm64";
    }
    const musl =
      process.platform === "linux" &&
      process.report?.getReport().header?.glibcVersionRuntime === undefined;
    const key = `${process.platform}-${cpu}${musl ? "-musl" : ""}`;
    const nativePackage = `@anthropic-ai/claude-code-${key}`;
    const owner = createRequire(wrapper);
    const meta = JSON.parse(
      fs.readFileSync(path.join(path.dirname(wrapper), "package.json"), "utf8"),
    );
    if (meta.optionalDependencies?.[nativePackage] !== "2.1.263")
      throw new Error(`Claude Code is not packaged for ${key}`);
    const manifestPath = owner.resolve(`${nativePackage}/package.json`);
    const manifest = JSON.parse(fs.readFileSync(manifestPath, "utf8"));
    if (manifest.name !== nativePackage || manifest.version !== "2.1.263")
      throw new Error(`Vela requires ${nativePackage}@2.1.263`);
    const entry = path.join(
      path.dirname(manifestPath),
      process.platform === "win32" ? "claude.exe" : "claude",
    );
    if (!fs.statSync(entry).isFile())
      throw new Error("Claude Code native binary is missing");
    return fs.realpathSync(entry);
  } catch (error) {
    if (options.strict === true) throw error;
    return null;
  }
}
function resolveVelaDshBin(options = {}) {
  try {
    const entry = resolvePinnedRuntime(
      "@deepseek-ai/dsh",
      "0.1.2-rc.1",
      "lib/bin.js",
      true,
    );
    const adapter = resolvePinnedRuntime(
      "@deepseek-ai/dsh-llm-pi-ai",
      "0.1.2-rc.1",
      "lib/index.js",
      true,
    );
    // Root workspace overrides are not distributed with an npm package.
    // Validate the adapter's actual dependency before reporting DSH available;
    // checking Vela's top-level pi-ai could mask a different nested version.
    resolvePinnedRuntime(
      "@earendil-works/pi-ai",
      "0.84.4",
      "dist/index.js",
      true,
      createRequire(adapter),
    );
    return entry;
  } catch (error) {
    if (options.strict === true) throw error;
    return null;
  }
}
function resolveVelaDshProfile(options = {}) {
  try {
    const entry = path.join(__dirname, "runtime", "dsh-profile.mjs");
    if (!fs.statSync(entry).isFile())
      throw new Error("Vela DSH profile is missing");
    return fs.realpathSync(entry);
  } catch (error) {
    if (options.strict === true) throw error;
    return null;
  }
}

module.exports = {
  resolveVelaCliBin,
  resolveVelaPiBin,
  resolveVelaCodexBin,
  resolveVelaClaudeBin,
  resolveVelaDshBin,
  resolveVelaDshProfile,
};
