"use strict";

const fs = require("node:fs");
const path = require("node:path");

const platformPackages = {
  "darwin-arm64": "@powerformer/vela-cli-darwin-arm64",
  "darwin-x64": "@powerformer/vela-cli-darwin-x64",
  "linux-arm64": "@powerformer/vela-cli-linux-arm64",
  "linux-x64": "@powerformer/vela-cli-linux-x64",
  "win32-x64": "@powerformer/vela-cli-win32-x64",
};

function platformKey() {
  return `${process.platform}-${process.arch}`;
}

function unsupportedPlatformError() {
  return new Error(
    `Vela CLI is not packaged for ${process.platform}/${process.arch}`,
  );
}

function missingBinaryError(packageName, cause) {
  const details =
    cause instanceof Error && cause.message ? `: ${cause.message}` : "";
  return new Error(
    `Vela CLI binary package ${packageName} is not installed or is incomplete${details}`,
  );
}

function resolvePackageBinary(packageName) {
  const packageJSON = resolvePackageJSON(packageName);
  const binary = path.join(
    path.dirname(packageJSON),
    "bin",
    process.platform === "win32" ? "vela.exe" : "vela",
  );
  if (!fs.existsSync(binary)) {
    throw missingBinaryError(packageName);
  }
  return binary;
}

function resolvePackageJSON(packageName) {
  try {
    return require.resolve(`${packageName}/package.json`);
  } catch (error) {
    // Workspace/dev fallback: resolve the sibling platform package directory by
    // name when it is not yet linked into node_modules.
    const siblingDir = packageName.replace(/^@powerformer\//u, "");
    const sourcePackageJSON = path.resolve(
      __dirname,
      "..",
      siblingDir,
      "package.json",
    );
    if (
      Object.values(platformPackages).includes(packageName) &&
      fs.existsSync(sourcePackageJSON)
    ) {
      return sourcePackageJSON;
    }
    throw error;
  }
}

function resolveVelaCliBin(options = {}) {
  const strict = options.strict === true;
  const packageName = platformPackages[platformKey()];
  if (!packageName) {
    if (strict) {
      throw unsupportedPlatformError();
    }
    return null;
  }

  try {
    return resolvePackageBinary(packageName);
  } catch (error) {
    if (strict) {
      throw missingBinaryError(packageName, error);
    }
    return null;
  }
}

// Pi is an ESM-only package and deliberately does not export package.json.
// Follow this package's dependency search roots without importing its CLI.
function resolveVelaPiBin(options = {}) {
  const packageName = "@earendil-works/pi-coding-agent";
  try {
    for (const root of require.resolve.paths(packageName) ?? []) {
      if (path.basename(root) !== "node_modules") continue;
      const packageRoot = path.join(root, packageName);
      const manifestPath = path.join(packageRoot, "package.json");
      if (!fs.existsSync(manifestPath)) continue;
      const manifest = JSON.parse(fs.readFileSync(manifestPath, "utf8"));
      if (manifest.name !== packageName || manifest.version !== "0.85.1") {
        throw new Error(
          "Vela Pi requires @earendil-works/pi-coding-agent@0.85.1",
        );
      }
      const entry = path.join(packageRoot, "dist", "bundle", "cli.js");
      if (!fs.statSync(entry).isFile())
        throw new Error("Vela Pi CLI entry is missing");
      return fs.realpathSync(entry);
    }
    throw new Error("Vela Pi dependency is not installed");
  } catch (error) {
    if (options.strict === true) throw error;
    return null;
  }
}

module.exports = {
  resolveVelaCliBin,
  resolveVelaPiBin,
};
