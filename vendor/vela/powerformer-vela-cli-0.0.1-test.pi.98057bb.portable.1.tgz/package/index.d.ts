export declare function resolveVelaCliBin(options?: { strict?: boolean }): string | null;
/** Fixed Pi dependency's Node.js entry, suitable for VELA_PI_BIN. */
export declare function resolveVelaPiBin(options?: { strict?: boolean }): string | null;
