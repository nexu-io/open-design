export declare function resolveVelaCliBin(options?: { strict?: boolean }): string | null;
/** Fixed Pi dependency's Node.js entry, suitable for VELA_PI_BIN. */
export declare function resolveVelaPiBin(options?: { strict?: boolean }): string | null;
export declare function resolveVelaCodexBin(options?: { strict?: boolean }): string | null;
/** Fixed Claude Code native dependency, suitable for VELA_CLAUDE_BIN without postinstall. */
export declare function resolveVelaClaudeBin(options?: { strict?: boolean }): string | null;
export declare function resolveVelaDshBin(options?: { strict?: boolean }): string | null;
export declare function resolveVelaDshProfile(options?: { strict?: boolean }): string | null;
