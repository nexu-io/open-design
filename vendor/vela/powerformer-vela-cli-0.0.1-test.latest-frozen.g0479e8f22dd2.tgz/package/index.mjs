import fs from "node:fs";
import { createRequire } from "node:module";
import path from "node:path";
import { fileURLToPath } from "node:url";

const require = createRequire(import.meta.url);
export const resolveVelaPiBin = require("./index.cjs").resolveVelaPiBin;
export const resolveVelaCodexBin = require("./index.cjs").resolveVelaCodexBin;
export const resolveVelaClaudeBin = require("./index.cjs").resolveVelaClaudeBin;
export const resolveVelaDshBin = require("./index.cjs").resolveVelaDshBin;
export const resolveVelaDshProfile =
  require("./index.cjs").resolveVelaDshProfile;

const platformPackages = {
  "darwin-arm64": "@powerformer/vela-cli-darwin-arm64",
  "darwin-x64": "@powerformer/vela-cli-darwin-x64",
  "linux-arm64": "@powerformer/vela-cli-linux-arm64",
  "linux-x64": "@powerformer/vela-cli-linux-x64",
  "win32-x64": "@powerformer/vela-cli-win32-x64",
};

function platformKey() {
  return `${process.platform}-${process.arch}`;
}

function unsupportedPlatformError() {
  return new Error(
    `Vela CLI is not packaged for ${process.platform}/${process.arch}`,
  );
}

function missingBinaryError(packageName, cause) {
  const details =
    cause instanceof Error && cause.message ? `: ${cause.message}` : "";
  return new Error(
    `Vela CLI binary package ${packageName} is not installed or is incomplete${details}`,
  );
}

function resolvePackageBinary(packageName) {
  const packageJSON = resolvePackageJSON(packageName);
  const binary = path.join(
    path.dirname(packageJSON),
    "bin",
    process.platform === "win32" ? "vela.exe" : "vela",
  );
  if (!fs.existsSync(binary)) {
    throw missingBinaryError(packageName);
  }
  return binary;
}

function resolvePackageJSON(packageName) {
  try {
    return require.resolve(`${packageName}/package.json`);
  } catch (error) {
    // Workspace/dev fallback: resolve the sibling platform package directory by
    // name when it is not yet linked into node_modules.
    const siblingDir = packageName.replace(/^@powerformer\//u, "");
    const sourcePackageJSON = path.resolve(
      path.dirname(fileURLToPath(import.meta.url)),
      "..",
      siblingDir,
      "package.json",
    );
    if (
      Object.values(platformPackages).includes(packageName) &&
      fs.existsSync(sourcePackageJSON)
    ) {
      return sourcePackageJSON;
    }
    throw error;
  }
}

export function resolveVelaCliBin(options = {}) {
  const strict = options.strict === true;
  const packageName = platformPackages[platformKey()];
  if (!packageName) {
    if (strict) {
      throw unsupportedPlatformError();
    }
    return null;
  }

  try {
    return resolvePackageBinary(packageName);
  } catch (error) {
    if (strict) {
      throw missingBinaryError(packageName, error);
    }
    return null;
  }
}
