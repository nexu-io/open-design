import { createManagedWeb } from "./managed-web-client.mjs";

export default async function registerWebTools(pi) {
  const web = createManagedWeb();
  pi.on("session_shutdown", () => web.close());
  try {
    await web.connect();
    for (const tool of await web.listTools()) {
      pi.registerTool({
        name: `parallel_${tool.name}`,
        label: tool.title || tool.name,
        description: tool.description || tool.name,
        parameters: tool.inputSchema,
        async execute(_id, args, signal) {
          const result = await web.callTool(tool.name, args, signal);
          if (result.isError) throw new Error(JSON.stringify(result.content));
          return { content: result.content, details: {} };
        },
      });
    }
  } catch (error) {
    await web.close();
    throw error;
  }
}
