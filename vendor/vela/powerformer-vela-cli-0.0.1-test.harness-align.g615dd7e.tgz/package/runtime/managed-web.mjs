import { createManagedWeb } from "./managed-web-client.mjs";

const controller = new AbortController();
const abort = () => controller.abort();
for (const signal of ["SIGINT", "SIGTERM"]) process.once(signal, abort);
const web = createManagedWeb({ signal: controller.signal });
try {
  const [tool, raw] = process.argv.slice(2);
  if (!["--help", "web_search", "web_fetch"].includes(tool)) {
    throw new Error(
      "Usage: managed-web.mjs --help | web_search '<JSON>' | web_fetch '<JSON>'",
    );
  }
  const args = tool === "--help" ? undefined : JSON.parse(raw);
  await web.connect();
  const result =
    tool === "--help"
      ? { tools: await web.listTools() }
      : await web.callTool(tool, args);
  process.stdout.write(`${JSON.stringify(result)}\n`);
  if (result.isError) process.exitCode = 1;
} catch (error) {
  process.stderr.write(`${error.message}\n`);
  process.exitCode = 1;
} finally {
  await web.close();
  for (const signal of ["SIGINT", "SIGTERM"])
    process.removeListener(signal, abort);
}
