import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";

const endpoint = "https://search.parallel.ai/mcp";
const timeout = 30000;

// Both adapters use the same service, discovery and cancellation policy.
export function createManagedWeb({
  signal,
  url = endpoint,
  timeoutMs = timeout,
} = {}) {
  const lifetime = new AbortController();
  const active = signal
    ? AbortSignal.any([signal, lifetime.signal])
    : lifetime.signal;
  const client = new Client({ name: "vela-managed-web", version: "1" });
  const options = { signal: active, timeout: timeoutMs };
  const transport = new StreamableHTTPClientTransport(new URL(url), {
    fetch: (input, init = {}) =>
      fetch(input, {
        ...init,
        signal: AbortSignal.any([
          active,
          AbortSignal.timeout(timeoutMs),
          ...(init.signal ? [init.signal] : []),
        ]),
      }),
  });
  return {
    async connect() {
      active.throwIfAborted();
      await client.connect(transport, options);
    },
    async listTools() {
      const tools = [];
      const cursors = new Set();
      let cursor;
      do {
        const page = await client.listTools({ cursor }, options);
        tools.push(...page.tools);
        cursor = page.nextCursor;
        if (cursor && cursors.has(cursor))
          throw new Error("Repeated MCP tool cursor");
        if (cursor) cursors.add(cursor);
      } while (cursor);
      return tools;
    },
    callTool(name, args, callSignal) {
      return client.callTool({ name, arguments: args }, undefined, {
        ...options,
        signal: callSignal ? AbortSignal.any([active, callSignal]) : active,
      });
    },
    async close() {
      lifetime.abort();
      await client.close();
    },
  };
}
